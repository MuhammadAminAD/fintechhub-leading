export const styles = {
      redBtn: "py-2 px-5 bg-[#FF6347] border border-[#FF6347] text-white text-lg font-medium leading-[150%] font-nunito",
      title: "text-wrap xl:text-[45px] font-bold font-unbounded text-white uppercase tracking-[-1%] leading-[100%]"
}